export const products = [
  {
    id: 1,
    section: "Aromáticas",
    name: "Menta",
    description: "Planta aromática ideal para infusiones y postres.",
    price: 3.5,
    image: "https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=facearea&w=400&q=80"
  },
  {
    id: 2,
    section: "Aromáticas",
    name: "Albahaca",
    description: "Perfecta para cocinar y aromatizar ambientes.",
    price: 4.0,
    image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=facearea&w=400&q=80"
  },
  {
    id: 3,
    section: "Medicinales",
    name: "Aloe Vera",
    description: "Planta con propiedades medicinales y fácil cuidado.",
    price: 6.0,
    image: "https://images.unsplash.com/photo-1501004318641-b39e6451bec6?auto=format&fit=facearea&w=400&q=80"
  },
  {
    id: 4,
    section: "Medicinales",
    name: "Lavanda",
    description: "Aroma relajante y uso en aceites esenciales.",
    price: 5.0,
    image: "https://images.unsplash.com/photo-1464983953574-0892a716854b?auto=format&fit=facearea&w=400&q=80"
  }
];