import { Link } from "react-router-dom";
import { useContext } from "react";
import { CartContext } from "../context/CartContext";

export default function Navbar() {
  const { cart } = useContext(CartContext);
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <nav style={{ padding: 12, background: "#8bc34a", display: "flex", gap: 16 }}>
      <Link to="/" style={{ fontWeight: "bold", color: "#fff" }}>Paradise Nursery</Link>
      <Link to="/products" style={{ color: "#fff" }}>Productos</Link>
      <Link to="/cart" style={{ color: "#fff" }}>
        Carrito 🛒 {totalItems > 0 && <span style={{ color: "#333", background: "#fff", borderRadius: "50%", padding: "2px 8px" }}>{totalItems}</span>}
      </Link>
    </nav>
  );
}