import { useContext } from "react";
import { CartContext } from "../context/CartContext";

export default function ProductCard({ plant }) {
  const { addToCart } = useContext(CartContext);

  return (
    <div style={{
      border: "1px solid #ccc",
      borderRadius: 8,
      padding: 16,
      margin: 8,
      minWidth: 230,
      textAlign: "center"
    }}>
      <img src={plant.image} alt={plant.name} style={{ width: "100%", height: 120, objectFit: "cover", borderRadius: 8 }} />
      <h3>{plant.name}</h3>
      <p>{plant.description}</p>
      <p><b>${plant.price}</b></p>
      <button onClick={() => addToCart(plant)}>Agregar al carrito</button>
    </div>
  );
}