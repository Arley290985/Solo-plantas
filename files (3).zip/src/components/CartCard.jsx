import { useContext } from "react";
import { CartContext } from "../context/CartContext";

export default function CartCard({ item }) {
  const { updateQuantity, removeFromCart } = useContext(CartContext);

  return (
    <div style={{
      display: "flex",
      alignItems: "center",
      gap: 16,
      border: "1px solid #ddd",
      borderRadius: 8,
      marginBottom: 12,
      padding: 12
    }}>
      <img src={item.image} alt={item.name} style={{ width: 64, height: 64, borderRadius: 8 }} />
      <div style={{ flex: 1 }}>
        <h4>{item.name}</h4>
        <div>Costo unitario: <b>${item.price}</b></div>
        <div>Costo total: <b>${(item.price * item.quantity).toFixed(2)}</b></div>
      </div>
      <div>
        <button onClick={() => updateQuantity(item.id, -1)} disabled={item.quantity === 1}>-</button>
        <span style={{ margin: "0 8px" }}>{item.quantity}</span>
        <button onClick={() => updateQuantity(item.id, 1)}>+</button>
      </div>
      <button onClick={() => removeFromCart(item.id)} style={{ color: "red", marginLeft: 8 }}>Eliminar</button>
    </div>
  );
}