import { useContext } from "react";
import { CartContext } from "../context/CartContext";
import CartCard from "../components/CartCard";
import { Link } from "react-router-dom";

export default function CartPage() {
  const { cart, clearCart } = useContext(CartContext);
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <div style={{ padding: 24 }}>
      <h2>Tu carrito</h2>
      {cart.length === 0 ? (
        <div>
          <p>El carrito está vacío.</p>
          <Link to="/products"><button>Continuar comprando</button></Link>
        </div>
      ) : (
        <>
          {cart.map(item => (
            <CartCard key={item.id} item={item} />
          ))}
          <h3>Total: ${total.toFixed(2)}</h3>
          <div style={{ display: "flex", gap: 12 }}>
            <Link to="/products"><button>Continuar comprando</button></Link>
            <button onClick={clearCart} style={{ background: "#8bc34a", color: "#fff" }}>Pagar</button>
          </div>
        </>
      )}
    </div>
  );
}