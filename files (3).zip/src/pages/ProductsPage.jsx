import ProductCard from "../components/ProductCard";
import { products } from "../data/products";

export default function ProductsPage() {
  const sections = Array.from(new Set(products.map(p => p.section)));

  return (
    <div style={{ padding: 24 }}>
      <h2>Nuestras Plantas</h2>
      {sections.map(section => (
        <div key={section} style={{ marginBottom: 32 }}>
          <h3>{section}</h3>
          <div style={{ display: "flex", flexWrap: "wrap" }}>
            {products.filter(p => p.section === section).map(plant => (
              <ProductCard key={plant.id} plant={plant} />
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}