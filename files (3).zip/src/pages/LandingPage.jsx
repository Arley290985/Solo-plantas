import { Link } from "react-router-dom";

export default function LandingPage() {
  return (
    <div style={{ textAlign: "center", marginTop: 60 }}>
      <h1>Bienvenido a Paradise Nursery</h1>
      <p>Tu tienda de plantas de interior favoritas</p>
      <Link to="/products">
        <button style={{ fontSize: 18, padding: "10px 25px", background: "#8bc34a", color: "#fff", border: "none", borderRadius: 6 }}>Ver Plantas</button>
      </Link>
    </div>
  );
}